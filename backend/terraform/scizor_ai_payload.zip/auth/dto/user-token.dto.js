"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeductTokenResultDto = exports.DeductTokenDto = exports.UpdateUserTokenDto = exports.UserTokenDto = exports.CreateUserTokenDto = void 0;
const class_validator_1 = require("class-validator");
class CreateUserTokenDto {
    user_id;
}
exports.CreateUserTokenDto = CreateUserTokenDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateUserTokenDto.prototype, "user_id", void 0);
class UserTokenDto {
    user_id;
    tokens;
    is_premium;
}
exports.UserTokenDto = UserTokenDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], UserTokenDto.prototype, "user_id", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UserTokenDto.prototype, "tokens", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", Boolean)
], UserTokenDto.prototype, "is_premium", void 0);
class UpdateUserTokenDto {
    tokens;
    is_premium;
}
exports.UpdateUserTokenDto = UpdateUserTokenDto;
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateUserTokenDto.prototype, "tokens", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", Boolean)
], UpdateUserTokenDto.prototype, "is_premium", void 0);
class DeductTokenDto {
    user_id;
    cost;
}
exports.DeductTokenDto = DeductTokenDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], DeductTokenDto.prototype, "user_id", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], DeductTokenDto.prototype, "cost", void 0);
class DeductTokenResultDto {
    success;
    message;
    remainingTokens;
}
exports.DeductTokenResultDto = DeductTokenResultDto;
//# sourceMappingURL=user-token.dto.js.map
export declare const authUtils: {};
